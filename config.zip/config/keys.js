module.exports = {
    mongoURI: 'mongodb+srv://dbAdmin:94XAF95TbHahjy3G@cluster0.u9tu2.mongodb.net/Desserts&Drinks?retryWrites=true&w=majority',
    secretOrKey: 'secret'
};